# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from atb_llm.common_op_builders.common_op_builder_manager import CommonOpBuilderManager
from atb_llm.common_op_builders.word_embedding.no_parallel_word_embedding_common_op_builder import \
    NoParallelWordEmbeddingCommonOpBuilder
from atb_llm.common_op_builders.word_embedding.all_gather_word_embedding_common_op_builder import \
    AllGatherWordEmbeddingCommonOpBuilder


CommonOpBuilderManager.register(AllGatherWordEmbeddingCommonOpBuilder)
CommonOpBuilderManager.register(NoParallelWordEmbeddingCommonOpBuilder)
